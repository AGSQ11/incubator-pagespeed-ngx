#define INCLUDE2_STRING "subdir/inc2/include2.h"
